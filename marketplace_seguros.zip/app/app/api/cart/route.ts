
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { getServerSession } from "next-auth";
import { authOptions } from "../auth/[...nextauth]/route";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { success: false, error: "No autorizado" },
        { status: 401 }
      );
    }

    const cart = await prisma.cart.findUnique({
      where: { userId: session.user.id },
      include: {
        items: {
          include: {
            product: {
              include: {
                insuranceType: true,
                country: true
              }
            }
          }
        }
      }
    });

    if (!cart) {
      // Crear carrito si no existe
      const newCart = await prisma.cart.create({
        data: { userId: session.user.id },
        include: {
          items: {
            include: {
              product: {
                include: {
                  insuranceType: true,
                  country: true
                }
              }
            }
          }
        }
      });
      
      return NextResponse.json({
        success: true,
        data: newCart
      });
    }

    return NextResponse.json({
      success: true,
      data: cart
    });

  } catch (error) {
    console.error("Error obteniendo carrito:", error);
    return NextResponse.json(
      { success: false, error: "Error interno del servidor" },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { success: false, error: "No autorizado" },
        { status: 401 }
      );
    }

    const { productId, quoteId, price, data } = await request.json();

    if (!productId || !price) {
      return NextResponse.json(
        { success: false, error: "Faltan campos requeridos" },
        { status: 400 }
      );
    }

    // Obtener o crear carrito
    let cart = await prisma.cart.findUnique({
      where: { userId: session.user.id }
    });

    if (!cart) {
      cart = await prisma.cart.create({
        data: { userId: session.user.id }
      });
    }

    // Verificar si el producto ya está en el carrito
    const existingItem = await prisma.cartItem.findFirst({
      where: {
        cartId: cart.id,
        productId
      }
    });

    if (existingItem) {
      return NextResponse.json(
        { success: false, error: "Este producto ya está en tu carrito" },
        { status: 400 }
      );
    }

    // Agregar item al carrito
    const cartItem = await prisma.cartItem.create({
      data: {
        cartId: cart.id,
        productId,
        quoteId,
        price: Number(price),
        data
      },
      include: {
        product: {
          include: {
            insuranceType: true,
            country: true
          }
        }
      }
    });

    return NextResponse.json({
      success: true,
      data: cartItem
    });

  } catch (error) {
    console.error("Error agregando al carrito:", error);
    return NextResponse.json(
      { success: false, error: "Error interno del servidor" },
      { status: 500 }
    );
  }
}
