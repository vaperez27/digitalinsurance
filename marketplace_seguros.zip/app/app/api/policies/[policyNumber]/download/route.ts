
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { getServerSession } from "next-auth";
import { authOptions } from "../../../auth/[...nextauth]/route";

export const dynamic = "force-dynamic";

export async function GET(
  request: NextRequest,
  { params }: { params: { policyNumber: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { success: false, error: "No autorizado" },
        { status: 401 }
      );
    }

    const policy = await prisma.policy.findUnique({
      where: { 
        policyNumber: params.policyNumber,
        userId: session.user.id
      },
      include: {
        product: {
          include: {
            insuranceType: true,
            country: true
          }
        },
        order: true,
        user: true
      }
    });

    if (!policy) {
      return NextResponse.json(
        { success: false, error: "Póliza no encontrada" },
        { status: 404 }
      );
    }

    // Simular generación de PDF (aquí se implementaría la generación real del PDF)
    const policyPDF = `
      PÓLIZA DE SEGURO ${policy.product.insuranceType.name.toUpperCase()}
      
      Número de Póliza: ${policy.policyNumber}
      Fecha de Emisión: ${policy.createdAt.toLocaleDateString()}
      Fecha de Inicio: ${policy.startDate.toLocaleDateString()}
      Fecha de Vencimiento: ${policy.endDate.toLocaleDateString()}
      
      ASEGURADO:
      Nombre: ${policy.user.name}
      Email: ${policy.user.email}
      
      PRODUCTO:
      ${policy.product.name}
      Compañía: ${policy.product.company}
      Prima Anual: ${policy.product.currency} ${policy.premium}
      
      COBERTURA:
      ${JSON.stringify(policy.coverage, null, 2)}
      
      CARACTERÍSTICAS:
      ${policy.product.features.join('\n')}
      
      Esta póliza es válida hasta ${policy.endDate.toLocaleDateString()}.
      
      Emitido por: Seguros Marketplace
    `;

    // Retornar como archivo de texto plano (en un caso real sería un PDF)
    return new Response(policyPDF, {
      headers: {
        'Content-Type': 'text/plain',
        'Content-Disposition': `attachment; filename="poliza-${policy.policyNumber}.txt"`
      }
    });

  } catch (error) {
    console.error("Error descargando póliza:", error);
    return NextResponse.json(
      { success: false, error: "Error interno del servidor" },
      { status: 500 }
    );
  }
}
