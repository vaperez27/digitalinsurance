
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  try {
    const countries = await prisma.country.findMany({
      where: { active: true },
      orderBy: { name: 'asc' }
    });

    return NextResponse.json({
      success: true,
      data: countries
    });

  } catch (error) {
    console.error("Error obteniendo países:", error);
    return NextResponse.json(
      { success: false, error: "Error interno del servidor" },
      { status: 500 }
    );
  }
}
