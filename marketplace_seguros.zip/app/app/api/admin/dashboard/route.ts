
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { getServerSession } from "next-auth";
import { authOptions } from "../../auth/[...nextauth]/route";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id || session.user.role !== 'admin') {
      return NextResponse.json(
        { success: false, error: "No autorizado" },
        { status: 401 }
      );
    }

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const [
      totalOrders,
      totalRevenue,
      newUsersToday,
      activePolicies,
      todayOrders,
      pendingOrders,
      recentOrders,
      topProducts,
      salesByCountry
    ] = await Promise.all([
      prisma.order.count(),
      prisma.order.aggregate({
        _sum: { total: true },
        where: { status: 'paid' }
      }),
      prisma.user.count({
        where: {
          createdAt: { gte: today },
          role: 'user'
        }
      }),
      prisma.policy.count({
        where: { status: 'active' }
      }),
      prisma.order.count({
        where: { createdAt: { gte: today } }
      }),
      prisma.order.count({
        where: { status: 'pending' }
      }),
      prisma.order.findMany({
        take: 5,
        include: {
          user: true,
          items: {
            include: {
              product: {
                include: { insuranceType: true }
              }
            }
          }
        },
        orderBy: { createdAt: 'desc' }
      }),
      // Top productos más vendidos
      prisma.orderItem.groupBy({
        by: ['productId'],
        _count: { productId: true },
        _sum: { price: true },
        orderBy: { _count: { productId: 'desc' } },
        take: 5
      }),
      // Ventas por país
      prisma.order.groupBy({
        by: ['countryId'],
        _count: { id: true },
        _sum: { total: true },
        where: { status: 'paid' }
      })
    ]);

    // Obtener detalles de productos top
    const topProductsDetails = await Promise.all(
      topProducts.map(async (item) => {
        const product = await prisma.insuranceProduct.findUnique({
          where: { id: item.productId },
          include: { insuranceType: true, country: true }
        });
        return {
          product,
          sales: item._count.productId,
          revenue: Number(item._sum.price) || 0
        };
      })
    );

    // Obtener detalles de países
    const salesByCountryDetails = await Promise.all(
      salesByCountry.map(async (item) => {
        const country = await prisma.country.findUnique({
          where: { id: item.countryId }
        });
        return {
          country,
          sales: item._count.id,
          revenue: Number(item._sum.total) || 0
        };
      })
    );

    const dashboardStats = {
      totalOrders,
      totalRevenue: Number(totalRevenue._sum.total) || 0,
      newUsers: newUsersToday,
      activePolicies,
      todayOrders,
      pendingOrders,
      recentOrders,
      topProducts: topProductsDetails,
      salesByCountry: salesByCountryDetails
    };

    return NextResponse.json({
      success: true,
      data: dashboardStats
    });

  } catch (error) {
    console.error("Error obteniendo dashboard:", error);
    return NextResponse.json(
      { success: false, error: "Error interno del servidor" },
      { status: 500 }
    );
  }
}
