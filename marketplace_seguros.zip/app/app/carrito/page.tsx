
"use client"

import React, { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import Image from 'next/image'
import Header from '@/components/layout/header'
import Footer from '@/components/layout/footer'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Cart, CartItem } from '@/lib/types'
import { ShoppingCart, Trash2, CreditCard, ArrowLeft } from 'lucide-react'
import { toast } from 'react-hot-toast'
import Link from 'next/link'

const CartPage = () => {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [cart, setCart] = useState<Cart | null>(null)
  const [loading, setLoading] = useState(true)
  const [removingItems, setRemovingItems] = useState<Set<string>>(new Set())

  useEffect(() => {
    if (status === 'loading') return
    
    if (!session?.user) {
      router.push('/login')
      return
    }

    fetchCart()
  }, [session, status, router])

  const fetchCart = async () => {
    try {
      const response = await fetch('/api/cart')
      if (response.ok) {
        const result = await response.json()
        if (result.success) {
          setCart(result.data)
        }
      }
    } catch (error) {
      console.error('Error fetching cart:', error)
      toast.error('Error al cargar el carrito')
    } finally {
      setLoading(false)
    }
  }

  const removeItem = async (itemId: string) => {
    setRemovingItems(prev => new Set(prev).add(itemId))
    
    try {
      const response = await fetch(`/api/cart/${itemId}`, {
        method: 'DELETE'
      })

      if (response.ok) {
        setCart(prev => {
          if (!prev) return prev
          return {
            ...prev,
            items: prev.items.filter(item => item.id !== itemId)
          }
        })
        toast.success('Producto eliminado del carrito')
      } else {
        toast.error('Error al eliminar el producto')
      }
    } catch (error) {
      console.error('Error removing item:', error)
      toast.error('Error al eliminar el producto')
    } finally {
      setRemovingItems(prev => {
        const newSet = new Set(prev)
        newSet.delete(itemId)
        return newSet
      })
    }
  }

  const calculateTotal = () => {
    if (!cart?.items) return 0
    return cart.items.reduce((total, item) => total + Number(item.price), 0)
  }

  const calculateTaxes = () => {
    return calculateTotal() * 0.16 // 16% IVA
  }

  const formatPrice = (price: number, currency?: string, symbol?: string) => {
    const currencySymbol = symbol || '$'
    return `${currencySymbol}${price.toLocaleString()}`
  }

  const handleCheckout = () => {
    if (!cart?.items || cart.items.length === 0) {
      toast.error('Tu carrito está vacío')
      return
    }
    router.push('/checkout')
  }

  if (status === 'loading' || loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="container mx-auto max-w-6xl px-4 py-8">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-200 rounded w-1/4 mb-8"></div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 space-y-4">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="h-32 bg-gray-200 rounded"></div>
                ))}
              </div>
              <div className="h-80 bg-gray-200 rounded"></div>
            </div>
          </div>
        </div>
        <Footer />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="container mx-auto max-w-6xl px-4 py-8">
        {/* Header */}
        <div className="flex items-center space-x-4 mb-8">
          <Link href="/">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <h1 className="text-3xl font-bold text-gray-900">Carrito de Compras</h1>
        </div>

        {!cart?.items || cart.items.length === 0 ? (
          <div className="text-center py-16">
            <ShoppingCart className="h-24 w-24 text-gray-300 mx-auto mb-4" />
            <h2 className="text-2xl font-semibold text-gray-600 mb-2">
              Tu carrito está vacío
            </h2>
            <p className="text-gray-500 mb-8">
              Añade algunos seguros para comenzar tu compra
            </p>
            <Link href="/">
              <Button variant="cta" size="lg">
                Explorar Seguros
              </Button>
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Cart Items */}
            <div className="lg:col-span-2 space-y-6">
              {cart.items.map((item) => (
                <Card key={item.id}>
                  <CardContent className="p-6">
                    <div className="flex items-start space-x-4">
                      {/* Company Logo */}
                      {item.product?.companyLogo && (
                        <div className="relative w-16 h-16 rounded-lg overflow-hidden bg-gray-100 flex-shrink-0">
                          <Image
                            src={item.product.companyLogo}
                            alt={`${item.product.company} logo`}
                            fill
                            className="object-contain"
                          />
                        </div>
                      )}

                      {/* Product Info */}
                      <div className="flex-1">
                        <div className="flex items-start justify-between">
                          <div>
                            <h3 className="text-lg font-semibold text-gray-900">
                              {item.product?.name}
                            </h3>
                            <p className="text-sm text-gray-600 mb-1">
                              {item.product?.company}
                            </p>
                            <Badge variant="outline" className="text-xs">
                              {item.product?.insuranceType?.name}
                            </Badge>
                          </div>
                          
                          <div className="text-right">
                            <p className="text-xl font-bold text-[#005A9C]">
                              {formatPrice(
                                Number(item.price), 
                                item.product?.currency, 
                                item.product?.country?.currencySymbol
                              )}
                            </p>
                            <p className="text-sm text-gray-500">por año</p>
                          </div>
                        </div>

                        {/* Product Features */}
                        {item.product?.features && item.product.features.length > 0 && (
                          <div className="mt-4">
                            <p className="text-sm font-medium text-gray-700 mb-2">
                              Características principales:
                            </p>
                            <div className="flex flex-wrap gap-2">
                              {item.product.features.slice(0, 3).map((feature, index) => (
                                <Badge key={index} variant="secondary" className="text-xs">
                                  {feature}
                                </Badge>
                              ))}
                              {item.product.features.length > 3 && (
                                <Badge variant="outline" className="text-xs">
                                  +{item.product.features.length - 3} más
                                </Badge>
                              )}
                            </div>
                          </div>
                        )}

                        {/* Remove Button */}
                        <div className="mt-4 flex justify-end">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeItem(item.id)}
                            disabled={removingItems.has(item.id)}
                            className="text-red-600 hover:text-red-700 hover:bg-red-50"
                          >
                            <Trash2 className="h-4 w-4 mr-2" />
                            {removingItems.has(item.id) ? 'Eliminando...' : 'Eliminar'}
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Order Summary */}
            <div className="lg:col-span-1">
              <Card className="sticky top-4">
                <CardHeader>
                  <CardTitle>Resumen del Pedido</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Subtotal ({cart.items.length} producto{cart.items.length !== 1 ? 's' : ''})</span>
                      <span>{formatPrice(calculateTotal())}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>IVA (16%)</span>
                      <span>{formatPrice(calculateTaxes())}</span>
                    </div>
                    <Separator />
                    <div className="flex justify-between text-lg font-semibold">
                      <span>Total</span>
                      <span className="text-[#005A9C]">
                        {formatPrice(calculateTotal() + calculateTaxes())}
                      </span>
                    </div>
                  </div>

                  <Button 
                    className="w-full" 
                    variant="cta" 
                    size="lg"
                    onClick={handleCheckout}
                  >
                    <CreditCard className="h-4 w-4 mr-2" />
                    Proceder al Pago
                  </Button>

                  <div className="text-center">
                    <Link href="/">
                      <Button variant="ghost" className="text-sm">
                        Continuar Comprando
                      </Button>
                    </Link>
                  </div>

                  {/* Security Notice */}
                  <div className="bg-green-50 p-3 rounded-lg">
                    <p className="text-xs text-green-700 text-center">
                      🔒 Compra 100% segura con encriptación SSL
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        )}
      </div>

      <Footer />
    </div>
  )
}

export default CartPage
