
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { getServerSession } from "next-auth";
import { authOptions } from "../auth/[...nextauth]/route";

export const dynamic = "force-dynamic";

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    
    if (!session?.user?.id) {
      return NextResponse.json(
        { success: false, error: "No autorizado" },
        { status: 401 }
      );
    }

    const { buyerName, buyerEmail, buyerPhone, buyerDocument } = await request.json();

    if (!buyerName || !buyerEmail) {
      return NextResponse.json(
        { success: false, error: "Faltan campos requeridos" },
        { status: 400 }
      );
    }

    // Obtener carrito con items
    const cart = await prisma.cart.findUnique({
      where: { userId: session.user.id },
      include: {
        items: {
          include: {
            product: {
              include: {
                country: true
              }
            }
          }
        }
      }
    });

    if (!cart || cart.items.length === 0) {
      return NextResponse.json(
        { success: false, error: "El carrito está vacío" },
        { status: 400 }
      );
    }

    // Calcular totales
    const subtotal = cart.items.reduce((sum, item) => sum + Number(item.price), 0);
    const taxes = subtotal * 0.16; // 16% IVA
    const total = subtotal + taxes;

    // Generar número de orden único
    const orderNumber = `ORD-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`.toUpperCase();

    // Crear orden
    const order = await prisma.order.create({
      data: {
        userId: session.user.id,
        orderNumber,
        status: "pending",
        subtotal,
        taxes,
        total,
        currency: cart.items[0].product.country.currency,
        countryId: cart.items[0].product.countryId,
        buyerName,
        buyerEmail,
        buyerPhone,
        buyerDocument,
        paymentStatus: "pending",
        items: {
          create: cart.items.map(item => ({
            productId: item.productId,
            quantity: item.quantity,
            price: item.price,
            data: item.data
          }))
        }
      },
      include: {
        items: {
          include: {
            product: {
              include: {
                insuranceType: true,
                country: true
              }
            }
          }
        },
        country: true
      }
    });

    // Simular procesamiento de pago exitoso (aquí iría la integración con Stripe)
    await prisma.order.update({
      where: { id: order.id },
      data: {
        status: "paid",
        paymentStatus: "paid",
        paymentMethod: "stripe",
        paymentId: `pay_${Date.now()}`
      }
    });

    // Crear pólizas para cada item
    const policies = [];
    for (const item of order.items) {
      const policyNumber = `POL-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`.toUpperCase();
      
      const startDate = new Date();
      const endDate = new Date();
      endDate.setFullYear(endDate.getFullYear() + 1); // Póliza por 1 año

      const policy = await prisma.policy.create({
        data: {
          userId: session.user.id,
          orderId: order.id,
          productId: item.productId,
          policyNumber,
          status: "active",
          startDate,
          endDate,
          premium: item.price,
          coverage: item.product.coverage,
          documents: {
            policyUrl: `/api/policies/${policyNumber}/download`,
            certificateUrl: `/api/policies/${policyNumber}/certificate`
          }
        }
      });
      policies.push(policy);
    }

    // Limpiar carrito
    await prisma.cartItem.deleteMany({
      where: { cartId: cart.id }
    });

    return NextResponse.json({
      success: true,
      data: {
        order: {
          ...order,
          policies
        }
      }
    });

  } catch (error) {
    console.error("Error procesando checkout:", error);
    return NextResponse.json(
      { success: false, error: "Error interno del servidor" },
      { status: 500 }
    );
  }
}
