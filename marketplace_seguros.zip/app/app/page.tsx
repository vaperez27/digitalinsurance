
"use client"

import React, { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import Image from 'next/image'
import { motion } from 'framer-motion'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import Header from '@/components/layout/header'
import Footer from '@/components/layout/footer'
import QuoteForm from '@/components/marketplace/quote-form'
import ProductCard from '@/components/marketplace/product-card'
import { 
  Car, 
  Heart, 
  Shield, 
  Plane, 
  AlertTriangle, 
  CheckCircle, 
  Star,
  TrendingUp,
  Users,
  Award
} from 'lucide-react'
import { QuoteFormData, InsuranceProduct } from '@/lib/types'

const HomePage = () => {
  const router = useRouter()
  const [featuredProducts, setFeaturedProducts] = useState<InsuranceProduct[]>([])
  const [activeTab, setActiveTab] = useState('auto')
  const [showQuoteForm, setShowQuoteForm] = useState(false)

  useEffect(() => {
    fetchFeaturedProducts()
  }, [])

  const fetchFeaturedProducts = async () => {
    try {
      const response = await fetch('/api/products?limit=6')
      if (response.ok) {
        const result = await response.json()
        if (result.success) {
          setFeaturedProducts(result.data || [])
        }
      }
    } catch (error) {
      console.error('Error fetching products:', error)
    }
  }

  const handleQuoteSubmit = async (data: QuoteFormData) => {
    try {
      // Find product based on insurance type and country
      const response = await fetch(`/api/products?insuranceTypeId=${data.insuranceType}&countryId=${data.countryId}&limit=1`)
      if (response.ok) {
        const result = await response.json()
        if (result.success && result.data.length > 0) {
          const product = result.data[0]
          
          // Create quote
          const quoteResponse = await fetch('/api/quotes', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              productId: product.id,
              personalData: data.personalData,
              vehicleData: data.vehicleData,
              travelData: data.travelData,
              healthData: data.healthData,
              countryId: data.countryId
            })
          })
          
          if (quoteResponse.ok) {
            const quoteResult = await quoteResponse.json()
            if (quoteResult.success) {
              router.push(`/cotizacion?quote=${quoteResult.data.id}`)
            }
          }
        }
      }
    } catch (error) {
      console.error('Error creating quote:', error)
    }
  }

  const insuranceTypes = [
    {
      id: 'auto',
      name: 'Auto',
      icon: Car,
      description: 'Protege tu vehículo con la mejor cobertura',
      color: 'bg-blue-500'
    },
    {
      id: 'vida',
      name: 'Vida',
      icon: Heart,
      description: 'Seguridad económica para tu familia',
      color: 'bg-red-500'
    },
    {
      id: 'salud',
      name: 'Salud',
      icon: Shield,
      description: 'Cobertura médica completa',
      color: 'bg-green-500'
    },
    {
      id: 'viaje',
      name: 'Viaje',
      icon: Plane,
      description: 'Viaja tranquilo con nuestra protección',
      color: 'bg-purple-500'
    },
    {
      id: 'accidentes',
      name: 'Accidentes',
      icon: AlertTriangle,
      description: 'Protección contra accidentes personales',
      color: 'bg-orange-500'
    }
  ]

  const features = [
    {
      icon: CheckCircle,
      title: 'Cotización Rápida',
      description: 'Obtén tu cotización en menos de 5 minutos'
    },
    {
      icon: Star,
      title: 'Mejores Aseguradoras',
      description: 'Trabajamos con las compañías más confiables'
    },
    {
      icon: TrendingUp,
      title: 'Precios Competitivos',
      description: 'Compara y encuentra el mejor precio'
    },
    {
      icon: Users,
      title: 'Atención Personalizada',
      description: 'Soporte 24/7 para todos nuestros clientes'
    }
  ]

  const stats = [
    { number: '50,000+', label: 'Clientes Satisfechos' },
    { number: '100+', label: 'Productos Disponibles' },
    { number: '4', label: 'Países' },
    { number: '24/7', label: 'Soporte' }
  ]

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-[#005A9C] to-[#004080] text-white overflow-hidden">
        <div className="absolute inset-0 bg-black/20" />
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-30"
          style={{
            backgroundImage: `url('https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEhkoY9v3lA7Sjv8v1qRMHFE-k-YIEAonytySRwgJiAAFOh4jEBisvdcvQ3VxPlYbpVEmmWYSuWqvqWkQazNcaLeyegUE1Y7Ovu2XaN4MgGuMD8p0lw2Z1pX1IFMnxQ27Phpip7SfBetCgYtf8ErUDzMisVlwFHYUzzYxm1EMiuWe04cNx4fAnHhnJytiQ/w640-h360/Blue%20Modern%20Happy%20Children%20Day%20Facebook%20Cover.png')`
          }}
        />
        
        <div className="relative container mx-auto max-w-6xl px-4 py-20 lg:py-32">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center lg:text-left"
            >
              <h1 className="text-4xl lg:text-6xl font-bold mb-6 leading-tight">
                Tu seguro, <span className="text-[#FF7A00]">simple</span> y en un solo lugar
              </h1>
              <p className="text-xl lg:text-2xl mb-8 text-blue-100">
                Cotiza, compara y contrata seguros de las mejores compañías en minutos
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                <Button 
                  size="lg" 
                  variant="cta" 
                  className="text-lg px-8 py-6"
                  onClick={() => setShowQuoteForm(true)}
                >
                  Cotizar Ahora
                </Button>
                <Button 
                  size="lg" 
                  variant="outline" 
                  className="text-lg px-8 py-6 bg-white/10 border-white text-white hover:bg-white hover:text-[#005A9C]"
                >
                  Ver Productos
                </Button>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="hidden lg:block"
            >
              <div className="relative">
                <div className="absolute inset-0 bg-white/10 rounded-2xl backdrop-blur-sm" />
                <div className="relative p-8 rounded-2xl">
                  <h3 className="text-2xl font-semibold mb-6">Cotización Rápida</h3>
                  <div className="grid grid-cols-2 gap-4">
                    {insuranceTypes.slice(0, 4).map((type, index) => {
                      const Icon = type.icon
                      return (
                        <motion.button
                          key={type.id}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ duration: 0.5, delay: 0.4 + index * 0.1 }}
                          className={`p-4 rounded-lg ${type.color} hover:scale-105 transition-transform duration-200 text-left`}
                          onClick={() => {
                            setActiveTab(type.id)
                            setShowQuoteForm(true)
                          }}
                        >
                          <Icon className="h-8 w-8 mb-2" />
                          <p className="font-semibold">{type.name}</p>
                          <p className="text-sm opacity-90">{type.description}</p>
                        </motion.button>
                      )
                    })}
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto max-w-6xl px-4">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="text-center"
              >
                <div className="text-3xl lg:text-4xl font-bold text-[#005A9C] mb-2">
                  {stat.number}
                </div>
                <div className="text-gray-600 font-medium">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Insurance Types Section */}
      <section className="py-20">
        <div className="container mx-auto max-w-6xl px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Nuestros Seguros
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Encuentra el seguro perfecto para ti con nuestras opciones de cobertura
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {insuranceTypes.map((type, index) => {
              const Icon = type.icon
              return (
                <motion.div
                  key={type.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <Card className="h-full hover:shadow-lg transition-all duration-200 group cursor-pointer">
                    <CardHeader className="text-center pb-4">
                      <div className={`w-16 h-16 ${type.color} rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-200`}>
                        <Icon className="h-8 w-8 text-white" />
                      </div>
                      <CardTitle className="text-xl group-hover:text-[#005A9C] transition-colors">
                        Seguro de {type.name}
                      </CardTitle>
                      <CardDescription className="text-base">
                        {type.description}
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="text-center">
                      <Button 
                        variant="outline" 
                        className="w-full group-hover:bg-[#005A9C] group-hover:text-white transition-colors"
                        onClick={() => {
                          setActiveTab(type.id)
                          setShowQuoteForm(true)
                        }}
                      >
                        Cotizar Ahora
                      </Button>
                    </CardContent>
                  </Card>
                </motion.div>
              )
            })}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      {featuredProducts.length > 0 && (
        <section className="py-20 bg-gray-50">
          <div className="container mx-auto max-w-6xl px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="text-center mb-16"
            >
              <h2 className="text-4xl font-bold text-gray-900 mb-4">
                Productos Destacados
              </h2>
              <p className="text-xl text-gray-600">
                Los seguros más populares entre nuestros clientes
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {featuredProducts.slice(0, 6).map((product, index) => (
                <motion.div
                  key={product.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  viewport={{ once: true }}
                >
                  <ProductCard 
                    product={product} 
                    onQuote={(product) => {
                      setActiveTab(product.insuranceType?.slug || 'auto')
                      setShowQuoteForm(true)
                    }}
                  />
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Features Section */}
      <section className="py-20">
        <div className="container mx-auto max-w-6xl px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              ¿Por qué elegir Seguros Marketplace?
            </h2>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  className="text-center"
                >
                  <div className="w-16 h-16 bg-[#FF7A00] rounded-full flex items-center justify-center mx-auto mb-4">
                    <Icon className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">
                    {feature.title}
                  </h3>
                  <p className="text-gray-600">
                    {feature.description}
                  </p>
                </motion.div>
              )
            })}
          </div>
        </div>
      </section>

      {/* Quote Form Modal */}
      {showQuoteForm && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-4 border-b flex justify-between items-center">
              <h2 className="text-2xl font-bold">Solicitar Cotización</h2>
              <Button 
                variant="ghost" 
                size="icon"
                onClick={() => setShowQuoteForm(false)}
              >
                ×
              </Button>
            </div>
            <div className="p-6">
              <QuoteForm 
                onSubmit={handleQuoteSubmit}
                selectedType={activeTab}
              />
            </div>
          </div>
        </div>
      )}

      <Footer />
    </div>
  )
}

export default HomePage
